App = function()
{
           this.tempo=180; 
       
    // this is where the WADE app is initialized
	this.init = function()
	{
             
            
	          
	          	wade.loadScene('hog_home_page.wsc', false, function()
        {
            // the scene has been loaded, do something here

        });
	          
	   
	
       

	};
	this.load =function(){
	     
	      
	
	wade.loadAudio('SmallExplosion8-Bit.ogg');

	};

};
